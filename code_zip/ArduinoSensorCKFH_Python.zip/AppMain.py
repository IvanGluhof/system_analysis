import socket
import time
import serial
from bluetooth import *

services = find_service(address=None)
for svc in services:
    print("\nService Name:",  svc["name"])
    print("    Host:       ", svc["host"])
    print("    Description:", svc["description"])
    print("    Provided By:", svc["provider"])
    print("    Protocol:   ", svc["protocol"])
    print("    channel/PSM:", svc["port"])
    print("    svc classes:", svc["service-classes"])
    print("    profiles:   ", svc["profiles"])
    print("    service id: ", svc["service-id"])


nearby_devices = discover_devices(lookup_names = True)

print("found %d devices" % len(nearby_devices))

for BT_MAC, BT_NAME in nearby_devices:
     print(" %s - %s" % (BT_MAC, BT_NAME))

HOST = BT_MAC # Symbolic name
PORT = 3      # Non-privileged port

# Create the client socket
sock=BluetoothSocket( RFCOMM )
sock.connect((HOST, PORT))

# L2CAP
# RFCOMM
s=BluetoothSocket( RFCOMM )
s.bind((HOST, PORT))
s.listen(1)

conn, addr = s.accept()

print('Connected by', addr)
while True:
    data = conn.recv(1024)
    if not data: break
conn.close()

exit(0)


BAUDRATE = 9600
COM_PORT = 'COM4' # Port with incoming data
TIMEOUT  = 2

# Bluetooth port
serial_bt = serial.Serial(port     = COM_PORT,
                          baudrate = BAUDRATE)
serial_bt.timeout = TIMEOUT  # Read timeout

# Check if port is opened
print(serial_bt.is_open)  # True for opened

if( serial_bt.is_open ):
    while True:
        size = serial_bt.inWaiting()
        if( size ):
            data = serial_bt.read(size)
            print(data)
        else:
            print('No data to read')
        time.sleep(1)
else:
    print('Port: ', COM_PORT, ' is not open')